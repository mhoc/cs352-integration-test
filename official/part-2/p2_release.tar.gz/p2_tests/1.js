<script type="text/JavaScript">
var a  = {}
</script>
