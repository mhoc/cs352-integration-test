<script type="text/JavaScript">
var a = "<br />";
document.write("a", a);
</script>
