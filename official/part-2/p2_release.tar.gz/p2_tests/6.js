<script type="text/JavaScript">
var a = {}
a.foo = 2;
a.bar = 2;
</script>
