<script type="text/JavaScript">
var b = 2;
var c = 3;
var a = 1 + b * 3 + (c + 3)*2;
a = a + 1;
document.write(a);
</script>
