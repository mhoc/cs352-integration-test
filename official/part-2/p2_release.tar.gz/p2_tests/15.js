<script type="text/JavaScript">
var a = 1 + "a";
var b = a + 2;
</script>
