<script type="text/JavaScript">
var a;
var b = a + 2;
</script>
