<script type="text/JavaScript">
var a = {};
document.write(a);
</script>
