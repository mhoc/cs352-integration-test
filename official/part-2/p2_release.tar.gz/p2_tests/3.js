<script type="text/JavaScript">
var a = {field:2, foo:"abe"}
</script>
