<script type="text/JavaScript">
var a = 1;
var a;
var b = a + 2;
</script>
