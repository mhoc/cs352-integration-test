<script type="text/JavaScript">
var a = "a" + 1;
</script>
