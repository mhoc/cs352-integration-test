<script type="text/JavaScript">
var a = {};
var b = {};
a.foo = b;
</script>
