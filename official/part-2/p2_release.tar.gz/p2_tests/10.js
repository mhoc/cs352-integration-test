<script type="text/JavaScript">
var a = 1 + "a" + 3;
</script>
