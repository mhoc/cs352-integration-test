<script type="text/JavaScript">
var a = {}
a.foo = 2;
</script>
