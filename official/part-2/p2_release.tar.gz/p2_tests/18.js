<script type="text/JavaScript">
var a = "Hello" + " World;";
var b = " Goodbye, World";
document.write(a + b);
</script>
