<script type="text/JavaScript">
var a = {foo:2};
a.foo = 3;
var foo = 5;
document.write(a.foo);
</script>
